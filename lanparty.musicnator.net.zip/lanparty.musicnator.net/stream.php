<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <link rel="shortcut icon" type="image/png" href="images/favicon.png">

    <meta charset="utf-8">
    <title>LanParty 2019</title>
  </head>
  <body style="background-color:black;">


    <iframe
        src="https://player.twitch.tv/?channel=dyrus"
        width="80%"
        height="750px"
        frameborder="none"
        scrolling="no"
        allowfullscreen="true"
        style="float:left;">
    </iframe>

    <iframe frameborder="0"
        scrolling="no"
        id="chat_embed"
        src="https://www.twitch.tv/embed/dyrus/chat"
        height="750"
        width="20%"
        style="float:right;">
</iframe>


</body>
</html>
